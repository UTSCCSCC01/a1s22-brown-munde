package ca.utoronto.utm.mcs;

public class Server {
    // TODO Complete This Class
}
