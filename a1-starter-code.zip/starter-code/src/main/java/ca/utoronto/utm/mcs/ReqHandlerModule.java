package ca.utoronto.utm.mcs;

import dagger.Module;

@Module
public class ReqHandlerModule {
    // TODO Complete This Module
}
