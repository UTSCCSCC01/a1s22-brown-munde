package ca.utoronto.utm.mcs;

import dagger.Module;

@Module
public class ServerModule {
    // TODO Complete This Module
}
