package ca.utoronto.utm.mcs;

// All your database transactions or queries should 
// go in this class
public class Neo4jDAO {
    // TODO Complete This Class
}
