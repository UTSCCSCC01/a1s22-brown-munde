package ca.utoronto.utm.mcs;

import java.io.IOException;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class ReqHandler implements HttpHandler {

    // TODO Complete This Class

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        
    }
}